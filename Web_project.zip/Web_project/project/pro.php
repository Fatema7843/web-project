<?php

echo $_GET["name"];
echo " ";

echo "<br>";
?>