<?php

echo $_GET["fname"];
echo " ";
echo $_GET["lname"];





echo $_GET["age"];
echo " ,";
echo $_GET["ename"];
echo $_GET["age"];
echo " ,";
echo $_GET["pass"];

$pass=$_POST[]


echo $_GET["age"];
echo " ,";
echo "<br>";
?>