<!DOCTYPE html>
<html>
<body>
<h1>E-Governance</h1><br>
<a href="https://www.w3schools.com/">Home</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">About Us</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">Contact</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">Our Success</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">History</a>
<hr>
<hr>
<form action="Control/pro.php" method="get">
<p>Electronic governance or e-governance can be defined as the usage of Information and Communication Technology <a href="https://www.w3schools.com/">ICT</a> by the government to provide and facilitate government services, exchange of information, communication transactions and integration of various standalone systems and services.</p>
<p>
  

<label for="need"><h4>  What is E-Governance</h4></label>
  <select id="need" name="need" size="5">
   <option value="fundingg">1.
Electronic Governance is the application of Information and Communication Technologies (ICTs) for delivering government services through integration of various stand-alone systems between Government-to-Citizens (G2C), Government-to-Business (G2B), and Government-to-Government(G2G) services. It is often linked with back office processes and interactions within the entire government framework. Through e-Governance, the government services are made available to the citizens in a convenient, efficient, and transparent manner. Learn more in: Cyber Capability Framework: A Tool to Evaluate ICT for Development Projects </option>
    <option value="jobb"> 2.
The use of emerging information and communication technologies (ICT) to facilitate the processes of government and public administration. It is about providing citizens with the ability to choose the manner in which they wish to interact with their governments. And it is about the choices governments make about how ICT will be deployed to support citizen choices. Learn more in: The E-Governance Concerns in Information System Design for Effective E-Government Performance Improvement </option>
    <option value="job11"> 3.
It is the application of information and communication technology for delivering government services, exchange of information and transactions. Learn more in: Direct Benefit Transfer Using Aadhaar: Improving Transparency and Reducing Corruption </option>
    <option value="job22"> 4.
Communication by electronic means to place power in the hands of citizens to determine what laws need to be made and how these laws should be written. Learn more in: Bridging the Digital Divide in Scotland </option>
    <option value="otherss4"> 5.
The use of information and communication technologies (ICTs) to support citizen services, government administration, democratic processes, and relationships among citizens, civil society, the private sector, and the state. Learn more in: Digital-Locker Services in India: An Assessment of User Adoption and Challenges </option>
  

 <option value="otherss1"> 6.
E-Governance is defined as that stage of e-government that inculcates digital democracy, online citizen participation, and online public discussion along with the aspects of online public service delivery. Learn more in: E-Governance and Quality of Life: Associating Municipal E-Governance with Quality of Life Worldwide 

 </option>

 <option value="otherss2"> 7.
It means ‘electronic governance’ which has evolved as an information-age model of governance that seeks to realize processes and structures for harnessing the potentialities of ICT at various levels of government and the public sector and beyond for the purpose of enhancing good governance. Learn more in: Platform for Citizen Engagement for Good Governance in India: A Case Study of MyGov.in 

 </option>

 <option value="otherss3"> 8.
It is the application of information communication technology for delivering institution services, exchange of information, communication transactions, integration of various stand-alone systems between government to citizen. Learn more in: Transformation of Historically Black Universities in South Africa to Provide Access to Information 

 </option> </select><br><br>




<img src ="file:///C:/Users/User/Downloads/e-Governance.jpg"></img><br>

<p>
<a href="https://www.w3schools.com/">LogIn</a>OR
<a href="https://www.w3schools.com/">Create an Account</a></p>

<p>
<h3>Create an Account</h3></p>
<h4>
<table>
<tr>
<td> Name : </td>
<td><input type="text" name="name" placeholder="enter your name"></td>

</tr>
</table></h4>

<p>
    <h4>
<table>
<tr>
<td> Phone Number     : </td>
<td><input type="text" name="phone" placeholder="enter your p.number"></td>

</tr>
</table></h4></h4></p>

<p>
    <h4>
<table>
<tr>
<td> Address : </td>
<td><input type="text" name="address" placeholder="enter your address"></td>

</tr>
</table></h4></h4></p>
<p>
    <h4>
<table>
<tr>
<td> Email : </td>
<td><input type="text" name="email" placeholder="enter your email"></td>

</tr>
</table></h4></h4></p>
<p>
    <h4>
<table>
<tr>
<td>Create a Password : </td>
<td><input type="text" name="password" placeholder="password"></td>

</tr>
</table></h4></h4></p>

    
  <h4>  
Preferred language : </h4>
<input type="checkbox" name="d12">English
<input type="checkbox" name="d112">Bangla
 
<input type="checkbox" name="d1112">Hindi

<p></br>
<h3>OR</h3></p>
<label for="need"><h4>  Preferred language :</h4></label>
  <select id="need" name="need" size="3">
    <option value="funding">English</option>
    <option value="job">Bangla</option>
    <option value="job1">Arabic</option>
    <option value="job2">Spanish</option>
    <option value="others">Hindi</option></p>
  </select><br><br>

<p></br>
<input type="submit"name="b11" value="Submit">
<h2>OR LogIn</h2></p>


<table>
<tr>
<td> Name : </td>
<td><input type="text" name="nname" placeholder="enter your name"></td>


<table>
 
<tr>
<p>
<td> Password : </td>
<td><input type="text" name="pname" placeholder="enter your password"></td></p>

</table><p>
<input type="submit"name="b11" value="LogIn"></p>
</form>
</body>


</body>
<p></p>
<hr>
<hr>
<h1></h1><br>
&nbsp&nbsp&nbsp&nbspLearn More&nbsp&nbsp
<a href="https://www.w3schools.com/">GI Global</a>&nbsp&nbsp&nbsp| <a href="https://www.w3schools.com/">Membership</a>&nbsp&nbsp&nbsp| <a href="https://www.w3schools.com/">Management Team</a>&nbsp&nbsp&nbsp<br>
<p>
&nbsp&nbsp&nbsp&nbspResources For&nbsp&nbsp
<a href="https://www.w3schools.com/">Author Service</a>&nbsp&nbsp&nbsp| <a href="https://www.w3schools.com/">Distribution</a>&nbsp&nbsp&nbsp| <a href="https://www.w3schools.com/">Editors</a>&nbsp&nbsp&nbsp<br></p>
<p>
&nbsp&nbsp&nbsp&nbspMedia Center&nbsp&nbsp
<a href="https://www.w3schools.com/">Blogs</a>&nbsp&nbsp&nbsp| <a href="https://www.w3schools.com/">Catalogs</a>&nbsp&nbsp&nbsp

</html>