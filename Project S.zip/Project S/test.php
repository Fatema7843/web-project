
<!DOCTYPE html>
<html></html>
<body>
<h2>Citizen's</h2><br>
<hr>
<form action="Control/citizen.php" method="get">
<table>
<tr>
<td> Name : </td>
<td><input type="text" name="name" placeholder="enter your name"></td>

</tr>
</table>

What's your age? 
<input type="radio" name="d1">0-25 years
<input type="radio" name="d1">25-35 years
<input type="radio" name="d1">Above 35+</br>
<p>

<label for="need">What do you need?</label>
  <select id="need" name="need" size="2">
    <option value="funding">Funding</option>
    <option value="job">Job Facilities</option>
    <option value="others">Others</option></p>
  </select><br><br>


<p>
<input type="submit"name="b11" value="Submit"></p>


</form>




