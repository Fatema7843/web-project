
<!DOCTYPE html>
<html></html>
<body>
<h2>Home Page </h2><br>
<hr>

<!DOCTYPE html>
<html>
<body>
<h1>E-Governance</h1><br>
<a href="https://www.w3schools.com/">Home</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">About Us</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">Contact</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">Our Success</a>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<a href="https://www.w3schools.com/">History</a>
<hr>
<hr>
<form action="Control/pro.php" method="get">
<p>Electronic governance or e-governance can be defined as the usage of Information and Communication Technology <a href="https://www.w3schools.com/">ICT</a> by the government to provide and facilitate government services, exchange of information, communication transactions and integration of various standalone systems and services.</p>
<p>
  

<label for="need"><h4>  What is E-Governance</h4></label>
  <select id="need" name="need" size="7">
   <option value="fundingg">1.
Electronic Governance is the application of Information and Communication Technologies (ICTs) for delivering government services through integration of various stand-alone systems between Government-to-Citizens (G2C), Government-to-Business (G2B), and Government-to-Government(G2G) services. It is often linked with back office processes and interactions within the entire government framework. Through e-Governance, the government services are made available to the citizens in a convenient, efficient, and transparent manner. Learn more in: Cyber Capability Framework: A Tool to Evaluate ICT for Development Projects </option>
    <option value="jobb"> 2.
The use of emerging information and communication technologies (ICT) to facilitate the processes of government and public administration. It is about providing citizens with the ability to choose the manner in which they wish to interact with their governments. And it is about the choices governments make about how ICT will be deployed to support citizen choices. Learn more in: The E-Governance Concerns in Information System Design for Effective E-Government Performance Improvement </option>
    <option value="job11"> 3.
It is the application of information and communication technology for delivering government services, exchange of information and transactions. Learn more in: Direct Benefit Transfer Using Aadhaar: Improving Transparency and Reducing Corruption </option>
    <option value="job22"> 4.
Communication by electronic means to place power in the hands of citizens to determine what laws need to be made and how these laws should be written. Learn more in: Bridging the Digital Divide in Scotland </option>
    <option value="otherss4"> 5.
The use of information and communication technologies (ICTs) to support citizen services, government administration, democratic processes, and relationships among citizens, civil society, the private sector, and the state. Learn more in: Digital-Locker Services in India: An Assessment of User Adoption and Challenges </option>
  

 <option value="otherss1"> 6.
E-Governance is defined as that stage of e-government that inculcates digital democracy, online citizen participation, and online public discussion along with the aspects of online public service delivery. Learn more in: E-Governance and Quality of Life: Associating Municipal E-Governance with Quality of Life Worldwide 

 </option>

 <option value="otherss2"> 7.
It means ‘electronic governance’ which has evolved as an information-age model of governance that seeks to realize processes and structures for harnessing the potentialities of ICT at various levels of government and the public sector and beyond for the purpose of enhancing good governance. Learn more in: Platform for Citizen Engagement for Good Governance in India: A Case Study of MyGov.in 

 </option>

 <option value="otherss3"> 8.
It is the application of information communication technology for delivering institution services, exchange of information, communication transactions, integration of various stand-alone systems between government to citizen. Learn more in: Transformation of Historically Black Universities in South Africa to Provide Access to Information 

<option value="otherss4"> 5.
The use of information and communication technologies (ICTs) to support citizen services, government administration, democratic processes, and relationships among citizens, civil society, the private sector, and the state. Learn more in: Digital-Locker Services in India: An Assessment of User Adoption and Challenges </option>
  

 <option value="otherss1"> 6.
E-Governance is defined as that stage of e-government that inculcates digital democracy, online citizen participation, and online public discussion along with the aspects of online public service delivery. Learn more in: E-Governance and Quality of Life: Associating Municipal E-Governance with Quality of Life Worldwide 

 </option>

 <option value="otherss2"> 7.
It means ‘electronic governance’ which has evolved as an information-age model of governance that seeks to realize processes and structures for harnessing the potentialities of ICT at various levels of government and the public sector and beyond for the purpose of enhancing good governance. Learn more in: Platform for Citizen Engagement for Good Governance in India: A Case Study of MyGov.in 

 </option>

 <option value="otherss3"> 8.
It is the application of information communication technology for delivering institution services, exchange of information, communication transactions, integration of various stand-alone systems between government to citizen. Learn more in: Transformation of Historically Black Universities in South Africa to Provide Access to Information 
<option value="otherss4"> 5.
The use of information and communication technologies (ICTs) to support citizen services, government administration, democratic processes, and relationships among citizens, civil society, the private sector, and the state. Learn more in: Digital-Locker Services in India: An Assessment of User Adoption and Challenges </option>
  

 <option value="otherss1"> 6.
E-Governance is defined as that stage of e-government that inculcates digital democracy, online citizen participation, and online public discussion along with the aspects of online public service delivery. Learn more in: E-Governance and Quality of Life: Associating Municipal E-Governance with Quality of Life Worldwide 

 </option>

 <option value="otherss2"> 7.
It means ‘electronic governance’ which has evolved as an information-age model of governance that seeks to realize processes and structures for harnessing the potentialities of ICT at various levels of government and the public sector and beyond for the purpose of enhancing good governance. Learn more in: Platform for Citizen Engagement for Good Governance in India: A Case Study of MyGov.in 

 </option>

 <option value="otherss3"> 8.
It is the application of information communication technology for delivering institution services, exchange of information, communication transactions, integration of various stand-alone systems between government to citizen. Learn more in: Transformation of Historically Black Universities in South Africa to Provide Access to Information 

 </option> </select><br><br>




<img width="100" height="100" src ="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.researchgate.net%2Ffigure%2FE-Governance-vis-a-vis-E-Government_fig1_280070112&psig=AOvVaw1sF4UDFn5KDDGPuqAOcXsh&ust=1647831409286000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCIDhncHY0_YCFQAAAAAdAAAAABAD" alt=""></img><br>


<p>
<table>
<tr>
<td> Name : </td>
<td><input type="text" name="uname" placeholder="enter your name"></td>

</tr>
</table>

<table>
<tr>
<td> Your Image : </td>
<td><input type="file" name="image" placeholder="image"></td>

</tr>
</table>
<table>
<tr>
<td> Date of birth : </td>
<td><input type="date" name="date" placeholder="DOB"></td>

</tr>
</table>

Gender 
<input type="radio" name="d1">Male
<input type="radio" name="d1">Female
<input type="radio" name="d1">Others</br>

<table>
<tr>
<td> Parmanent Address : </td>
<td><input type="text" name="name" placeholder="enter your p.address"></td>

</tr>
</table>
<table>
<tr>
<td> Create Password : </td>
<td><input type="password" name="create_password" placeholder=""></td>

</tr>
</table>
<table>
<tr>
<td> Confirm Password : </td>
<td><input type="password" name="confirm_password" placeholder="confirm password"></td>

</tr>
</table>



<p>

<label for="need">What do you need?</label>
  <select id="need" name="need" size="2">
    <option value="funding">Funding</option>
    <option value="job">Job Facilities</option>
    <option value="others">Others</option></p></P>
  </select><br><br>


<p>
<input type="submit"name="b11" value="Submit"></p>



</form>




