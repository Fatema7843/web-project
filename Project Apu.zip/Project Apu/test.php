
<!DOCTYPE html>
<html></html>
<body>
<h2>Foreigner's</h2><br>
<hr>
<form action="Control/foreigner.php" method="get">
<table>
<tr>
<td> Name : </td>
<td><input type="text" name="name" placeholder="enter your name"></td>

</tr>
</table>

Which categories under you are ? 
<input type="radio" name="d1">Obtaiuned Civil rights
<input type="radio" name="d1">Visitors


<p>
<input type="submit"name="b13" value="Submit"></p>


</form>




