
Welcome<br>
<p>
<?php


if(isset($_GET["d3"]))
{

echo " name : ".$_GET["d3"];
}
else {

echo"You haven't selected any categories";}
echo "<br>";




?>


</p>

    


