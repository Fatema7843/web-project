<!DOCTYPE html>
<html></html>
<body>
<h2>Government</h2><br>
<hr>


<form action="Control/new.php" method="get">


Do you want to see info ? 
<input type="radio" name="d3">yes
<input type="radio" name="d3">no


<p>
<input type="submit"name="b14" value="Submit"></p>


</form>

</body>